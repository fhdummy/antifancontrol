/*
 * BitOperations.c
 *
 * Created: 24.04.2014 09:49:08
 *  Author: ITS
 */ 


#include <avr/io.h>
#include <util/delay.h>
#include "LCD.h"


int main(void)
{    
	char str[10] = "Hallo Welt";
	char strcount[6];
	long count = 100000;
	initDisplay();
	
	writeCharArray(str, sizeof(str)/sizeof(str[0]));
	
	while (1) {
		setCursor2Line();
		sprintf(strcount, "%ld", count);
		writeCharArray(strcount, sizeof(strcount)/sizeof(strcount[0]));
		if(count == 500000) count = 100000;
		count += 1000;
	}
	
	
}

